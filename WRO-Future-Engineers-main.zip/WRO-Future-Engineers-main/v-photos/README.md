Vehicle's photos
====

This directory must contain 6 photos of the vehicle (from every side, from top and bottom)